export declare function getTodos(): Promise<any>;
