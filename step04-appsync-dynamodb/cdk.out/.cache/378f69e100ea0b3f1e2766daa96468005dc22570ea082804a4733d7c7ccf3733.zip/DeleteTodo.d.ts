export declare function deleteTodo(todoId: string): Promise<any>;
