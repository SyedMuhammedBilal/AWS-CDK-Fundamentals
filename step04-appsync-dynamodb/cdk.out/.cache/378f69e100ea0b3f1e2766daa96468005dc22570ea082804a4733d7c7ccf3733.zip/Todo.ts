export interface Todo {
    id: string;
    title: string;
    done: boolean;
}