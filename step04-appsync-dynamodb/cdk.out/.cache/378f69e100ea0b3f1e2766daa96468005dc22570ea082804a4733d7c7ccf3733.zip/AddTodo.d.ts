import { Todo } from './Todo';
export declare const addTodo: (todo: Todo) => Promise<any>;
