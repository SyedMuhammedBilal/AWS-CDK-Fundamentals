export declare function updateTodo(todo: any): Promise<any>;
