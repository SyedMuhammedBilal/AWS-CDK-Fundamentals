declare type AppSyncEvent = {
    info: {
        fieldName: string;
    };
    arguments: {
        msg: string;
    };
};
